### Projeto POO

## Fluxo Principal do Projeto PediJá

1- Entrar(caso já tenha feito o cadastro) ou cadastrar no Parceiro;  
2- Ir na opção de "Gerenciar Cardápio";  
3- Ir até a opção "Adicionar Produto" e colocar as informações do produto adicionado;  
4- Depois de adicionado o produto, voltar até a página principal para escolher a opção "Consumidor";  
5- Entrar(caso já tenha feito o cadastro) ou cadastrar no Consumidor;  
6- Ir na opção "Buscar produtos" e digitar no nome do produto que havia adicionado;  
7- Adicionar o produto buscado no carrinho.   
8- Voltar ao "Menu Principal Consumidor" e navegar até a opção "Ver carrinho";  
9-  Apertar na opção "Finalizar Pedido" para concluir o pedido;
10- Escolher uma forma de pagamento;  
11- Escolher a opção "Confirmar Pedido";  
12- Depois disso, volte para a tela principal e escolha a opção “Parceiro” e entre com o login que havia feito anteriormente;  
13 - Acesse a opção “Gerenciar Pedidos” e o pedido, feito pelo consumidor antes, vai estar em “Pedidos Pendentes”;  
14- Vai ter a opção “Aceitar o Pedido” ou “Rejeitar”. Se aceitar o pedido, coloque o “tempo de preparo” e vai atualizar a tela e agora o pedido vai estar em “Pedidos em Preparo”;  
15- Ir na opção “Pedidos em Preparo” e marcar se o pedido está pronto;  
16- Após isso, o pedido vai estar em “Pedidos em Entrega”;  
17- Depois disso, volte para a tela principal e escolha a opção “Consumidor” e entre com o login que havia feito anteriormente;  
18- Vai até o "Menu Principal Consumidor";  
19- Escolha a opção "Ver Pedidos";  
20- Apertar na opção "Pedidos á Caminho" para ver o pedido que havia confirmado;  
21- Digitar o número do pedido visível na tela para ver mais informações dele;  
22- Confirmar ou não se o pedido foi recebido ou não pelo consumidor;  
23- Depois disso, o pedido vai estar na opção "Pedidos Concluídos" tanto para o “Consumidor” quanto para o “Parceiro”;  
24- Todas as outras funções são navegáveis ou visuais.  


## Conceitos de POO utilizados:  
1- Abstração: representamos entidades do mundo real (ou conceitos) no código, focando apenas nos atributos e comportamentos essenciais.  
2- Encapsulamento: protegemos os dados internos de um objeto, escondendo a complexidade e permitindo o acesso apenas por meio de métodos controlados (getters e setters).  
3- Polimorfismo: colocamos métodos para se comportarem de diferentes maneiras, dependendo do objeto que o invoca. Ele tem tanto comportamentos via via overriding (sobrescrita) ou overloading(sobrecarga).  
